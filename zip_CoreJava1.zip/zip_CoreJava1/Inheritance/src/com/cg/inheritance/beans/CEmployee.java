package com.cg.inheritance.beans;
public class CEmployee extends Employee {
	private int variablePay,hrs;
	public CEmployee() {
		super();
	}
	public CEmployee(int employeeID, int basicSalary, String firstName, String lastName,int hrs) {
		super(employeeID, basicSalary, firstName, lastName);
		this.hrs = hrs;
	}
	public CEmployee(int variablePay, int hrs) {
		super();
		this.variablePay = variablePay;
		this.hrs = hrs;
	}
	public int getVariablePay() {
		return variablePay;
	}
	public void setVariablePay(int variablePay) {
		this.variablePay = variablePay;
	}
	public int getHrs() {
		return hrs;
	}
	public void setHrs(int hrs) {
		this.hrs = hrs;
	}
	@Override
	public void calculateSalary() {
		super.calculateSalary();
		this.variablePay=hrs*1000;
		this.setTotalSalary(getTotalSalary()+hrs);
	}

	
}
