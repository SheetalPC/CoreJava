package com.cg.inheritance.beans;
public class Employee {
	private int employeeID,basicSalary,totalSalary;
	private String firstName,lastName;
	
	public Employee() {
		super();
	}

	public Employee(int employeeID, int basicSalary, String firstName, String lastName) {
		super();
		this.employeeID = employeeID;
		this.basicSalary = basicSalary;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public int getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}

	public int getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}

	public int getTotalSalary() {
		return totalSalary;
	}

	public void setTotalSalary(int totalSalary) {
		this.totalSalary = totalSalary;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public void calculateSalary() {
		totalSalary = basicSalary;
	}
	
}
