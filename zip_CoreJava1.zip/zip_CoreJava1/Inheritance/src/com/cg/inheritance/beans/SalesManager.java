package com.cg.inheritance.beans;
public class SalesManager extends PEmployee{
	private int salesAmount,commission;
	public SalesManager() {
		super();
	}
	public SalesManager(int employeeID, int basicSalary, String firstName, String lastName,int salesAmount) {
		super(employeeID, basicSalary, firstName, lastName);
		this.salesAmount = salesAmount;
	}
	public int getSalesAmount() {
		return salesAmount;
	}
	public void setSalesAmount(int salesAmount) {
		this.salesAmount = salesAmount;
	}
	public int getCommission() {
		return commission;
	}
	public void setCommission(int commission) {
		this.commission = commission;
	}
	public void SalesManagerProject() {
		System.out.println("Sales has Done");
	}
	@Override
	public void calculateSalary() {
		super.calculateSalary();
		this.setTotalSalary(getTotalSalary()+commission);
	}
	
	
}
