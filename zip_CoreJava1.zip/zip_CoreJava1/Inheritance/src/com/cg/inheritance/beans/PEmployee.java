package com.cg.inheritance.beans;
public class PEmployee extends Employee {
	private int hra,ta,da;
	public PEmployee() {
		super();
	}
	public PEmployee(int employeeID, int basicSalary, String firstName, String lastName) {
		super(employeeID, basicSalary, firstName, lastName);
	}
	public PEmployee(int hra, int ta, int da) {
		super();
		this.hra = hra;
		this.ta = ta;
		this.da = da;
	}
	public int getHra() {
		return hra;
	}
	public void setHra(int hra) {
		this.hra = hra;
	}
	public int getTa() {
		return ta;
	}
	public void setTa(int ta) {
		this.ta = ta;
	}
	public int getDa() {
		return da;
	}
	public void setDa(int da) {
		this.da = da;
	}
	@Override
	public void calculateSalary() {
		super.calculateSalary();
		this.hra=getTotalSalary()*10/100;
		this.ta=getTotalSalary()*10/100;
		this.da=getTotalSalary()*10/100;
		this.setTotalSalary(this.getTotalSalary()+hra+ta+da);
	}
}
