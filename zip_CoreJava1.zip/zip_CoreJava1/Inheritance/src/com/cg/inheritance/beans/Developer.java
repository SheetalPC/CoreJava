package com.cg.inheritance.beans;
public class Developer extends PEmployee{
	private int noOfProjectsDone,incentive;
	public Developer() {
		super();
	}
	public Developer(int employeeID, int basicSalary, String firstName, String lastName, int noOfProjectsDone) {
		super(employeeID, basicSalary, firstName, lastName);
		this.noOfProjectsDone = noOfProjectsDone;
	}
	public int getNoOfProjectsDone() {
		return noOfProjectsDone;
	}
	public void setNoOfProjectsDone(int noOfProjectsDone) {
		this.noOfProjectsDone = noOfProjectsDone;
	}
	public int getIncentive() {
		return incentive;
	}
	public void setIncentive(int incentive) {
		this.incentive = incentive;
	}
	public void developerProject() {
		System.out.println("Project has completed");
	}
	@Override
	public void calculateSalary() {
		super.calculateSalary();
		this.setTotalSalary(getTotalSalary()+incentive);
	}
}
