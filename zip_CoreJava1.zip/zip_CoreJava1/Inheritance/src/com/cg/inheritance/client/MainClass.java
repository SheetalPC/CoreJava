package com.cg.inheritance.client;
import com.cg.inheritance.beans.CEmployee;
import com.cg.inheritance.beans.Employee;
import com.cg.inheritance.beans.PEmployee;
import com.cg.inheritance.beans.Developer;
import com.cg.inheritance.beans.SalesManager;

public class MainClass {
public static void main(String[] args) {
	Employee emp = new Employee(111, 9000, "Sheetal", "Chotaliya");
	emp.calculateSalary();
	System.out.println(emp.getEmployeeID()+ " "+emp.getFirstName()+ " " +emp.getLastName()+ " " +emp.getTotalSalary());
	
	PEmployee pemp = new PEmployee(112, 3000, "Priyanka", "Patil");
	pemp.calculateSalary();
	System.out.println(pemp.getEmployeeID()+ " "+pemp.getFirstName()+ " " +pemp.getLastName()+ " " +pemp.getTotalSalary());
	
	CEmployee cemp = new CEmployee(113, 4000, "Sukanya", "Pimparkar", 5);
	cemp.calculateSalary();
	System.out.println(cemp.getEmployeeID()+ " "+cemp.getFirstName()+ " " +cemp.getLastName()+ " " +cemp.getTotalSalary());
	
	Developer dev = new Developer(114, 2000, "Renuka", "Deshmukh", 3);
	dev.calculateSalary();
	System.out.println(dev.getEmployeeID()+ " "+dev.getFirstName()+ " " +dev.getLastName()+ " " +dev.getTotalSalary());
	
	SalesManager sales = new SalesManager(115, 3000, "Anamika", "Bhadouriya", 4000);
	sales.calculateSalary();
	System.out.println(sales.getEmployeeID()+ " "+sales.getFirstName()+ " " +sales.getLastName()+ " " +sales.getTotalSalary());
	
}

}
