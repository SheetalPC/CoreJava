public class MainClass {
	public static void main(String[] args) {
		System.out.println("Person Details: ");
		System.out.println("First Name: Sheetal");
		System.out.println("Last Name: Chotaliya");
		System.out.println("Gender: F");
		System.out.println("Age: 22");
		System.out.println("Weigth: 40");
	}
}
