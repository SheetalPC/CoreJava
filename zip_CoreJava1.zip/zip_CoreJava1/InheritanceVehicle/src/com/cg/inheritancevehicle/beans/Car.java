package com.cg.inheritancevehicle.beans;
public class Car {

}
