package com.cg.project.lamdainterface;
@FunctionalInterface
	public interface FunctionalInterface3 {
	String toUpperCase(String name);
}
