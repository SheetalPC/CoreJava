package com.cg.project.lamdainterface;
@FunctionalInterface
public interface WorkService {
	void doSomeWork();
}
