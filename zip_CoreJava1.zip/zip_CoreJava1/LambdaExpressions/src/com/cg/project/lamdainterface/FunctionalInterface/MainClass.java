package com.cg.project.lamdainterface.FunctionalInterface;
import com.cg.project.lamdainterface.FunctionalInterface1;
import com.cg.project.lamdainterface.FunctionalInterface2;
import com.cg.project.lamdainterface.FunctionalInterface3;
import com.cg.project.lamdainterface.WorkService;
public class MainClass {
	public static void main(String[] args) {
		//FOR INTERFACE1
		//FunctionalInterface1 ref1 = (firstName,lastName) -> System.out.println("Good Morning " +firstName + " " + lastName);
		//ref1.greetUser("Sheetal","Chotaliya");

		//FOR INTERFACE2
		FunctionalInterface2 ref2 = (a,b) -> a+b;
		System.out.println(ref2.add(100,200));
		
		//FOR INTERFACE3
		//FunctionalInterface3 ref3 = (str) -> str.toUpperCase();
		//System.out.println(ref3.toUpperCase("hello world"));
		callForWork(()->System.out.println("Doing Some Work"));
	}
	public static void callForWork(WorkService service) {
		service.doSomeWork();
	}
	

}
