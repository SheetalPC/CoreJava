package com.cg.mobilebilling.beans;

public class Plan {
	private int planID,monthlyRental,freeLocalCalls,freeStdCalls,freeLocalSms,freeStdSms,freeInternetDataUsageUnits,localCallRate,stdCallRate,localSmsRate,stdSmsRate,internetDataUsageRate;
	private String planCircle,planName;
	
}
