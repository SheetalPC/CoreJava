package com.cg.mobilebilling.beans;

public class Bill {
	private int billID,noOfLocalSms,noOfStdSms,noOfLocalCalls,noOfStdCalls,internetDataUsageUnits,
	internetDataUsageUnitsAmount,billMonth,stateGST,centralGST,totalBillAmount,localSmsAmount,
	stdSmsAmount,localCallAmount;
}
