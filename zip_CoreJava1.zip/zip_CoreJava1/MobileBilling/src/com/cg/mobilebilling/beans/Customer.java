package com.cg.mobilebilling.beans;


public class Customer {
	private int customerID,adharNo,dateOfBirth;
	private String firstName,lastName,emailID,pancardNo;
	
	private PostPaidAccount postpaidaccount;
	
	PostPaidAccount [] postpaidaccount1 = new PostPaidAccount[3];

	
		
		public Customer(int customerID, int adharNo, int dateOfBirth, String firstName, String lastName, String emailID,
				String pancardNo, PostPaidAccount[] postpaidaccount[]) {
			super();
			this.customerID = customerID;
			this.adharNo = adharNo;
			this.dateOfBirth = dateOfBirth;
			this.firstName = firstName;
			this.lastName = lastName;
			this.emailID = emailID;
			this.pancardNo = pancardNo;
		
		}

		public int getCustomerID() {
			return customerID;
		}

		public void setCustomerID(int customerID) {
			this.customerID = customerID;
		}

		public int getAdharNo() {
			return adharNo;
		}

		public void setAdharNo(int adharNo) {
			this.adharNo = adharNo;
		}

		public int getDateOfBirth() {
			return dateOfBirth;
		}

		public void setDateOfBirth(int dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public String getEmailID() {
			return emailID;
		}

		public void setEmailID(String emailID) {
			this.emailID = emailID;
		}

		public String getPancardNo() {
			return pancardNo;
		}

		public void setPancardNo(String pancardNo) {
			this.pancardNo = pancardNo;
		}
		
}

