package com.cg.mobilebilling.beans;

public class PostPaidAccount {
	private int mobileNo;
	
	PostPaidAccount(){}
	


	public PostPaidAccount(int mobileNo) {
		super();
		this.mobileNo = mobileNo;
	}

	public int getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}

	
}
