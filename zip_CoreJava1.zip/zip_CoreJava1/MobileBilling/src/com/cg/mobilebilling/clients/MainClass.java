package com.cg.mobilebilling.clients;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.PostPaidAccount;
public class MainClass {
public static void main(String[] args) {
		
	//PostPaidAccount [] postpaidaccount = new PostPaidAccount[3];
	
	//postpaidaccount[0] = new PostPaidAccount(6337682);
	postpaidaccount[1] = new PostPaidAccount(2387283);
	postpaidaccount[2] = new PostPaidAccount(6328222);
			}
}
