package assignment;
public class QuadraticEquation {
public static void main(String[] args) {
	int a=1,b=-6,c=-16;
	double root1;
	double root2;
	double term;
	term=(b*b)-(4*a*c);
	root1=(-b + Math.sqrt(term)) / (2*a);
	root2=(-b - Math.sqrt(term)) / (2*a);
	System.out.println(root1);
	System.out.println(root2);
	}
}
