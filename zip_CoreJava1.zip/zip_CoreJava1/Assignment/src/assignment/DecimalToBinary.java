package assignment;
public class DecimalToBinary {
public static void main(String[] args) {
		int binary = 0,i=1,n=13,p=0,a,number=1101,decimal=0,r,s,q=0;
		while(n>0) {
			p=n%2;
			n=n/2;
			binary=binary+(p*i);
			i=i*10;
		}
		System.out.println(binary);
		
		while(number>0){
				
			a=number%10;
			number=number/10;
			
			decimal=decimal+(a)*(2^p);
			p++;
		}
		System.out.println(decimal);
	}

}