package assignment;
public class LcmHcf {
public static void main(String[] args) {
	int n1=72,n2=120,lcm,hcf;
	lcm = (n1>n2) ? n1 : n2;
	while(true) {
		if (lcm % n1 == 0 && lcm % n2 == 0)
			{
				System.out.println("LCM of 72 and 120 is: " +lcm);
				break;
			}
			lcm++;
		}
			hcf = (n1*n2)/lcm;
			System.out.println("HCF of 72 and 120 is: "+hcf);
	}
}
