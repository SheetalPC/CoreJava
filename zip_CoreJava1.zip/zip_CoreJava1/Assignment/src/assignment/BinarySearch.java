package assignment;
public class BinarySearch {
public static void main(String[] args) {
	int count,number=7,search,first,last,mid;
	int array[] = {4,5,66,77,5,99,0};
	search=77;
	first=0;
	last=number-1;
	mid=(first+last)/2;
	while(first <= last) {
		if(array[mid]<search)
			first=mid+1;
		else if(array[mid]==search) {
			System.out.println(search + " " + (mid + 1 ));
			break;
		}
		else
			last = mid-1;
		mid=(first+last)/2;
	}
	if(first>last) {
		System.out.println(search + "not found");		
	}
	}
}
