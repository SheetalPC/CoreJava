package com.cg.evenoddthread.client;
import com.cg.evenoddthread.RunnableResource;
public class MainClass {
	public static void main(String [] str) {
		RunnableResource runnableResource = new RunnableResource();
		Thread th3 = new Thread(runnableResource, "th3");
		th3.start();
		Thread th4 = new Thread(runnableResource, "th4");
		th4.start();
	}
	}
