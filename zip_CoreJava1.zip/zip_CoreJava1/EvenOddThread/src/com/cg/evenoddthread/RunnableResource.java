package com.cg.evenoddthread;
public class RunnableResource implements Runnable{
	@Override
	public void run() {
		Thread t = Thread.currentThread();
		if(t.getName().equals("th3")) {
			for(int i=1;i<=100;i++) {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if(i/2 == 0) {
					System.out.println(i+ "is Even Number" + t.getName());
				}
			}
		}
		else if(t.getName().equals("th4")) {
			for(int i=1;i<=100;i++) {
				System.out.println( i  + " is Odd Number " + t.getName());
			}
		}		
		}		
	}
