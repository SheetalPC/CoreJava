public class TwoDimentionalArray {
public static void main(String[] args) {
	int a=2,b=2,c=3;
	int [] [] [] numList = new int [a][b][c];
	for(int i=0;i<a;i++) {
		for(int j=0;j<b;j++) {
			for(int k=0;k<c;k++) {
				System.out.println("NumList is: "+numList[i][j][k]);
				}
			}
		}
	}
}