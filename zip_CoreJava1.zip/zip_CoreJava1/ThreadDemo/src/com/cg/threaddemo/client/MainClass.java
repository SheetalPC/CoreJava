package com.cg.threaddemo.client;
import com.cg.threaddemo.RunnableResource;
public class MainClass {
	public static void main(String[] args) {
	/*RunnableResource runnableResource = new RunnableResource();
	
	Thread th1 = new Thread(runnableResource, "th1");
	th1.start();
	Thread th2 = new Thread(runnableResource, "th2");
	th2.start();
*/
	/*	//	1	way-by directly giving lamda expression to the ref
	Runnable runnableResources = () -> {
		for(int i=0;i<11;i++) {
			System.out.println("Tick    " + i );
		}
	};
	
	Thread th1 = new Thread(runnableResources);
	th1.start();
	*/
		
		/*
	//2way
	Thread th2 = new Thread(() -> {
		for(int i=0;i<11;i++) {
			System.out.println("Tick    " + i );
	}
	});
	th2.start();
	*/
		
	//3way
	new Thread(()-> {
		for(int i=0;i<11;i++)
			System.out.println("Tick    " + i );
		}).start();
	}
}
