package com.cg.threaddemo;
public class RunnableResource implements Runnable{
	@Override
	public void run() {
	Thread t = Thread.currentThread();
	if(t.getName().equals("th1")) {
		for(int i=0;i<11;i++) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("Tick    " + i + "  " + t.getName());
		}
	}
	else if(t.getName().equals("th2")) {
		for(int i=0;i<11;i++) {
			System.out.println("Tok    " + i + "  " + t.getName());
		}
	}		
	}	
}
