package com.cg.pizzaorder.ui;
import java.util.Scanner;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exceptions.InvalidMobileNumberException;
import com.cg.pizzaorder.exceptions.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;

public class Client {
	public static void main(String[] args) throws PizzaException, InvalidMobileNumberException  {
		int orderID = (int) Math.random();	
		int customerID = (int) Math.random();
	        Scanner  sc=new Scanner(System.in);
	        IPizzaOrderService iPizzaOrderService=new PizzaOrderService();
		int ch;
		do {
			System.out.println("Enter your choice: \n 1. Place Order \n 2. Display Order \n 3. Exit");
			ch=sc.nextInt();
			switch(ch) {
			case 1 :  System.out.println("Enter your details: ");
						System.out.println("Enter your Name: ");
						String customerName = sc.next();
						System.out.println("Enter your Address: ");
						String address = sc.next();
						System.out.println("Enter your Phone Number: ");
						String phone = sc.next();
						System.out.println("Enter your Pizza Topping: ");
						String pizzaTopping = sc.next();
						double totalPrice=(double)iPizzaOrderService.priceCalculation(pizzaTopping);        
						int orderId=iPizzaOrderService.placeOrder(new Customer(customerName,address,phone), new PizzaOrder(totalPrice));
			            System.out.println("Pizza order successfully placed with Order Id :"+ orderId);
			            System.out.println("Total Price is: "+ totalPrice);
			            break;  
		case 2:	System.out.println("Enter Order Id:");
						int orderid=sc.nextInt();      
						PizzaOrder pizza1=iPizzaOrderService.getOrderDetails(orderid);                 
						System.out.println(pizza1.toString());
						break;
		case 3: System.exit(0);
						break;
		default: System.out.println("Pizza Order successfully placed with OrderID: " +orderID);
		}
    }while(ch<=3);
}
}