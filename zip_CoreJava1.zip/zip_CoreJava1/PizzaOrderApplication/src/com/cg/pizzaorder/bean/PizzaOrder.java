package com.cg.pizzaorder.bean;
public class PizzaOrder {
	private int orderId;
	private int customerId;
	private String pizzaTopping;
	private double totalPrice;
	public PizzaOrder() {
		super();
	}
	public PizzaOrder(int orderId, int customerId, double totalPrice) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.totalPrice = totalPrice;
	}
	public PizzaOrder(double totalPrice) {
		super();
		this.totalPrice = totalPrice;
	}
	
	public String getPizzaTopping() {
		return pizzaTopping;
	}
	public void setPizzaTopping(String pizzaTopping) {
		this.pizzaTopping = pizzaTopping;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	
}
