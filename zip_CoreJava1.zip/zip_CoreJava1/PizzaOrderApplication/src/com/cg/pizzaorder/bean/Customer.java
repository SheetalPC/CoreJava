package com.cg.pizzaorder.bean;
public class Customer {
	private int customerId;
	private String customerName;
	private String address;
	private String phone;
	public Customer() {
		super();
	}
	public Customer(String customerName, String address, String phone) {
		super();
		this.customerName = customerName;
		this.address = address;
		this.phone = phone;
	}

	public Customer(int customerId, String address, String phone) {
		super();
		this.customerId = customerId;
		this.address = address;
		this.phone = phone;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
