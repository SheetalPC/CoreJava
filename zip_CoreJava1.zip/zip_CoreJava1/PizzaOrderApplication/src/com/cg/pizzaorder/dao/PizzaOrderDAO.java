package com.cg.pizzaorder.dao;
import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exceptions.PizzaException;
public class PizzaOrderDAO implements IPizzaOrderDAO{

	 public static int ORDER_ID_COUNTER=10;  
	    public static int CUSTOMER_ID_COUNTER=100;  
	    public  static Map<Integer, Customer>customerEntry=new HashMap<>();
	    public  static Map<Integer, PizzaOrder>pizzaEntry=new HashMap<>();
	    
	    @Override
	    public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
	        customer.setCustomerId(getCUSTOMER_ID_COUNTER());
	        customerEntry.put(customer.getCustomerId(), customer);
	        pizza.setOrderId(getORDER_ID_COUNTER());
	        pizza.setCustomerId(getCUSTOMER_ID_COUNTER());
	        pizzaEntry.put(pizza.getOrderId(), pizza);
	        return pizza.getOrderId();
	    }
	    public static int getORDER_ID_COUNTER() {
	        return ++ORDER_ID_COUNTER;
	    }
	    public static int getCUSTOMER_ID_COUNTER() {
	        return ++CUSTOMER_ID_COUNTER;
	    }
		@Override
		public PizzaOrder getOrderDetails(int orderId) throws PizzaException {
			return pizzaEntry.get(orderId);
		}

	}
