package com.cg.pizzaorder.service;
import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exceptions.InvalidMobileNumberException;
import com.cg.pizzaorder.exceptions.PizzaException;

public interface IPizzaOrderService {
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException, InvalidMobileNumberException;
	public PizzaOrder getOrderDetails(int orderId) throws PizzaException;
	public int priceCalculation(String pizzaTopping);
}
