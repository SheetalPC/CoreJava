package com.cg.pizzaorder.service;
import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exceptions.InvalidMobileNumberException;
import com.cg.pizzaorder.exceptions.PizzaException;

public class PizzaOrderService implements IPizzaOrderService {
	IPizzaOrderDAO ipizzaorderdao=new PizzaOrderDAO();
	@Override
    public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException, InvalidMobileNumberException {
        if(customer.getPhone().length()>10) throw new InvalidMobileNumberException();
        {
        	int orderId=ipizzaorderdao.placeOrder(customer, pizza);  
        	return orderId;
        }
	}
    @Override
    public PizzaOrder getOrderDetails(int orderid) throws PizzaException {      
        return ipizzaorderdao.getOrderDetails(orderid);
    }
    @Override
    public int priceCalculation(String pizzaTopping) {
        int basePrice=350,totalPrice;       
        if(pizzaTopping.equals("Capsicum"))
            return totalPrice=basePrice+30;
        else if(pizzaTopping.equals("Mushroom"))
            return totalPrice=basePrice+50; 
        else if(pizzaTopping.equals("Jalapeno"))
            return totalPrice=basePrice+70; 
        else if(pizzaTopping.equals("Paneer"))
            return totalPrice=basePrice+85;          
         else
             return 0;
    }
}
