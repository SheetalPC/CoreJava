package com.cg.banking.client;
import com.cg.banking.bean.Customer;
import com.cg.banking.bean.Transaction;
import com.cg.banking.bean.Account;

public class MainClass {

	public static void main(String[] args) {
		Customer customer = new Customer();
}
}
