package com.cg.banking.bean;


public class Customer {
	private int customerID,mobileNumber,dateOf,Birth;
	private String firstName,lastName,emailID,adharNo,pancardNo;
	
	
}
