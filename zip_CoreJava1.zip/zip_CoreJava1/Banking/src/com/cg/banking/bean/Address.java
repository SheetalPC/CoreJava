package com.cg.banking.bean;

public class Address {
	private int pinCode;
	private String city,state,country;
}
