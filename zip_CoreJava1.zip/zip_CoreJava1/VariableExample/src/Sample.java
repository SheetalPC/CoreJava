public class Sample {
	public static int number;
		static {
		number = 10;
		number++;
		}
	int num1,num2;
	public Sample(int num1, int num2) {
		super();
		this.num1 = num1;
		this.num2 = num2;
	}
public static void main(String[] args) {
	Sample s1 = new Sample(5,6);
	Sample s2 = new Sample(1,2);
	
	s1.num1++;
	s1.num2++;
	
	s2.num1++;
	s2.num2++;
	
	System.out.println(s1.num1);
	System.out.println(s1.num2);
	System.out.println(Sample.number);
	
	System.out.println(s2.num1);
	System.out.println(s2.num2);
	}
}
