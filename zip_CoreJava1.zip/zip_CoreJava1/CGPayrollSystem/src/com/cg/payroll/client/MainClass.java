package com.cg.payroll.client;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServiesImpl;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import com.cg.payroll.ObjectSerialization;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public class MainClass {

	public static void main(String[] args) {
		//Associate [] associate = new Associate[5];
		
		/*associate[0] = new Associate(111, 1400, "Sheetal", "Chotaliya", "ABC", "JR", "YHG78", "sheetal@gmail.com", new Salary(25000, 768, 7844, 9877, 281, 50, 232, 323, 211, 839, 289), new BankDetails(12345, "HDFC"," hdfc657"));
		associate[1] = new Associate(112, 1500, "Shreya", "Patil", "DEF", "SR", "SDD89", "shreya@gmail.com", new Salary(30000, 986, 2234, 8930, 123, 78, 434, 879, 765, 932, 877), new BankDetails(6578, "HDFC"," hdfc8650"));
		associate[2] = new Associate(113, 1600, "Priyanka", "Patil", "UHY", "HR", "UID89", "priyanka@gmail.com", new Salary(35000, 876, 6732, 9873, 163, 39, 198, 231, 876, 121, 232), new BankDetails(12345, "ICICI"," icici755"));
		associate[3] = new Associate(114, 1700, "Anamika", "B", "IUY", "SR", "IUS975", "anamika@gmail.com", new Salary(19000, 872, 1234, 8473, 382, 83, 987, 232, 870, 221, 532), new BankDetails(9864, "HDFC"," hdfc342"));
		associate[4] = new Associate(115, 1800, "Shivangi", "S", "SOJ", "SR", "OIH086", "shivangi@gmail.com", new Salary(15000, 766, 7848, 9876, 251, 80, 432, 523, 711, 869, 286), new BankDetails(8765, "ICICI"," icici9876"));
		
		for(int i=0;i<associate.length;i++) {
			if(associate [i].getSalary().getBasicSalary() > 20000 && associate[i].getBankdetails().getBankName() == "HDFC") {
				System.out.println(associate[i].getFirstName() + " " +associate[i].getLastName());
			}
			*/
			Scanner sc = new Scanner(System.in);
			PayrollServices payrollService = new PayrollServiesImpl();
			
			
				/*System.out.println("Enter Details");
				System.out.println("Enter YearlyInvestment, firstName,lastName: ");
				int yearlyInvest = sc.nextInt();
				String firstName = sc.next();
				String lastName = sc.next();
				System.out.println("Enter department, designation, pancard, email, epf, companyPf");
				String department = sc.next();
				String designation = sc.next();
				String  pancard = sc.next();
				String  email= sc.next();
				int epf = sc.nextInt();
				int companyPf = sc.nextInt();
				System.out.println("Enter basicSalary, accountNo,bankName,ifscCode: ");
				int basicSalary = sc.nextInt();
				int accountNo = sc.nextInt();
				String bankName = sc.next();
				String ifscCode = sc.next();
				*/
				int associateId = payrollService.acceptAssociateDetails("Sheetal", "Chotaliya", "sheetal@gmail.com", "department",
						"analyst", "ABC678", 5, 9000, 56,90,
						78965,"icici", "icici345");
				System.out.println("Associate ID : " +associateId);
				
				/*int associateId = payrollService.acceptAssociateDetails("Sukanya", "Pimparkar", "sukku@gmail.com", "abc",
						"Sr.", "IUYT90", 8, 19000, 86,60,
						78965,"icici", "icici345");
				System.out.println("Associate ID : " +associateId);
				*/
				try {
				Associate associate = payrollService.getAssociateDetails(associateId);
				System.out.println(associate.toString());
				
				int calculatedSalary = payrollService.calculateNetSalary(associateId);
			} catch (AssociateDetailsNotFoundException e) {
				e.printStackTrace();
				
				System.out.println(payrollService.getAllAssociateDetails());
		}
	
	//Serialization
/*	
	try {
		File file = new File("D:\\PayrollData.txt");
		ObjectSerialization.doSerialization(file);
		ObjectSerialization.doDeSerialization(file);
	} catch (IOException | ClassNotFoundException e) {
		e.printStackTrace();
	}*/
}
}
