package com.cg.payroll;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServiesImpl;
public class ObjectSerialization {
	public static void doSerialization(File file) throws IOException {
		PayrollServices payrollService = new PayrollServiesImpl();
		int associateId = payrollService.acceptAssociateDetails("Sheetal", "Chotaliya", "sheetal@gmail.com", "department",
				"analyst", "ABC678", 5, 9000, 56,90,
				78965,"icici", "icici345");
		try(ObjectOutputStream destWriter = new ObjectOutputStream(new FileOutputStream(file))){
			destWriter.writeObject(payrollService);
			System.out.println("Object has written on " + file.getAbsolutePath());
		}
	}
	public static void doDeSerialization(File file)  throws FileNotFoundException, IOException, ClassNotFoundException{
		try(ObjectInputStream srcReader = new ObjectInputStream(new FileInputStream(file))){
			PayrollServices payrollService = (PayrollServices)srcReader.readObject();
			System.out.println(payrollService);
		}
	}
}
