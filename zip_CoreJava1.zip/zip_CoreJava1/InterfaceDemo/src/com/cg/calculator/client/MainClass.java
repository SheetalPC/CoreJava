package com.cg.calculator.client;
import java.util.InputMismatchException;
import java.util.Scanner;
public class MainClass {
public static void main(String[] args) {	
		try {
			Scanner ref = new Scanner(System.in);
				
				System.out.println("Enter First Number: ");
				int num1 = ref.nextInt();
				
				System.out.println("Enter Second Number: " );
				int num2 = ref.nextInt();
				
				System.out.println("Answer: "+num1/num2);
				
		} catch (InputMismatchException e) {
				System.err.println("Enter Only Numbers");
			e.printStackTrace();
		}
		catch (ArithmeticException e) {
			System.err.println(e.getMessage()+" "+"Enter Second Number other than 0");
		}
		catch (Exception e) {
			System.err.println("We'll can't say anything..");
		}
		System.out.println("Code after catch block");
	}
}
