package com.cg.calculator.services;
import com.cg.calculator.exception.InvalidNumberRangeException;

public class MathServicesImpl implements MathServices {
	int sum,sub,mul,div;
	@Override
	public int add(int n1, int n2) throws InvalidNumberRangeException{
		if((n1<0 && n2<0) || (n1<0 && n2>0) || (n1>0 && n2<0)) throw new InvalidNumberRangeException();
		else
		return sum = n1+n2;
	}

	@Override
	public int sub(int n1, int n2) throws InvalidNumberRangeException{
		if((n1<0 && n2<0) || (n1<0 && n2>0) || (n1>0 && n2<0)) throw new InvalidNumberRangeException();
		else
		return sub = n1-n2;
	}

	@Override
	public int multi(int n1, int n2) throws InvalidNumberRangeException{
		if((n1<0 && n2<0) || (n1<0 && n2>0) || (n1>0 && n2<0)) throw new InvalidNumberRangeException();
		else
		return mul = n1*n2;
	}

	@Override
	public int div(int n1, int n2) throws InvalidNumberRangeException{
		if((n1<0 && n2<0) || (n1<0 && n2>0) || (n1>0 && n2<0)) throw new InvalidNumberRangeException();
		else
		return div = n1/n2;
	}

}
