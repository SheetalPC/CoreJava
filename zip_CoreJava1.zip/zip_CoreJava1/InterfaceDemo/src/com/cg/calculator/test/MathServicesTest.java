package com.cg.calculator.test;
import static org.junit.Assert.*;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.calculator.exception.InvalidNumberRangeException;
import com.cg.calculator.services.MathServices;
import com.cg.calculator.services.MathServicesImpl;
public class MathServicesTest {

	private static MathServices mathServices;
	private int firstInvalidNumber,secondInvalidNumber,firstValidNumber,secondValidNumber;
	
	@BeforeClass
	public static void setUpTestEnv() {
		mathServices = new MathServicesImpl();
	}
	
	@Before
	public void setUpTestData() {
		firstInvalidNumber = -100;
		firstValidNumber = 500;
		secondInvalidNumber = -200;
		secondValidNumber = 200;
	}
	
	@Test(expected = InvalidNumberRangeException.class)
	public void testAddForFirstInvalidNumber() throws InvalidNumberRangeException{
		mathServices.add(firstInvalidNumber, secondValidNumber);
	}
	
	@Test(expected = InvalidNumberRangeException.class)
	public void testAddForSecondInvalidNumber() throws InvalidNumberRangeException{
		mathServices.add(firstValidNumber, secondInvalidNumber);
	}
	
	@Test
	public void testAddForBothValidNumber() throws InvalidNumberRangeException{
		int expectedAns = 700;
		int actualAns = mathServices.add(firstValidNumber, secondValidNumber);
		Assert.assertEquals(expectedAns, actualAns);
	}
	
//subtraction
	
	
	@Test(expected = InvalidNumberRangeException.class)
	public void testSubForFirstInvalidNumber() throws InvalidNumberRangeException{
		mathServices.add(firstInvalidNumber, secondValidNumber);
	}
	
	@Test(expected = InvalidNumberRangeException.class)
	public void testSubForSecondInvalidNumber() throws InvalidNumberRangeException{
		mathServices.add(firstValidNumber, secondInvalidNumber);
	}
	
	@Test
	public void testSubForBothValidNumber() throws InvalidNumberRangeException{
		int expectedAns = 700;
		int actualAns = mathServices.add(firstValidNumber, secondValidNumber);
		Assert.assertEquals(expectedAns, actualAns);
	}
	
	//multiplication
	@Test(expected = InvalidNumberRangeException.class)
	public void testMulForFirstInvalidNumberForMul() throws InvalidNumberRangeException{
		mathServices.multi(firstInvalidNumber, secondValidNumber);
	}
	
	@Test(expected = InvalidNumberRangeException.class)
	public void testMulForSecondInvalidNumberForMul() throws InvalidNumberRangeException{
		mathServices.multi(firstValidNumber, secondInvalidNumber);
	}
	
	@Test
	public void testMulForBothValidNumberForMul() throws InvalidNumberRangeException{
		int expectedAns = 100000;
		int actualAns = mathServices.multi(firstValidNumber, secondValidNumber);
		Assert.assertEquals(expectedAns, actualAns);
	}
	
	//division
	
		@Test(expected = InvalidNumberRangeException.class)
		public void testDivForFirstInvalidNumberForMul() throws InvalidNumberRangeException{
			mathServices.multi(firstInvalidNumber, secondValidNumber);
		}
		
		@Test(expected = InvalidNumberRangeException.class)
		public void testDivForSecondInvalidNumberForMul() throws InvalidNumberRangeException{
			mathServices.multi(firstValidNumber, secondInvalidNumber);
		}
		
		@Test
		public void testDivForBothValidNumberForMul() throws InvalidNumberRangeException{
			int expectedAns = 100000;
			int actualAns = mathServices.multi(firstValidNumber, secondValidNumber);
			Assert.assertEquals(expectedAns, actualAns);
		}
	
	@AfterClass
	public static void tearDownTestEnv() {
		mathServices = null;
	}
	
}
