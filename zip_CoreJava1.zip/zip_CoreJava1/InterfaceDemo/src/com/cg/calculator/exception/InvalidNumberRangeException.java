package com.cg.calculator.exception;

public class InvalidNumberRangeException extends Exception {

	public InvalidNumberRangeException() {
		super();
	}

	public InvalidNumberRangeException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

	public InvalidNumberRangeException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public InvalidNumberRangeException(String arg0) {
		super(arg0);
	}

	public InvalidNumberRangeException(Throwable arg0) {
		super(arg0);
	}

}
