package com.cg.inheritancestudent.client;
import com.cg.inheritancestudent.beans.Student;
import com.cg.inheritancestudent.beans.BscGraduate;
import com.cg.inheritancestudent.beans.BeGraduate;

public class MainClass {
public static void main(String[] args) {
	
	Student student;
	
	student = new BeGraduate(1, 100, "Sheetal", "Chotaliya", 4);
	student.calculateMarks();
	System.out.println(student.getRollNumber()+ " " +student.getFirstName()+ " " +student.getLastName()+ " "+student.getTotalMarks());
	
	student = new BscGraduate(2, 200, "Anamika", "Bhadouriya", 5);
	student.calculateMarks();
	System.out.println(student.getRollNumber()+ " " +student.getFirstName()+ " " +student.getLastName()+ " "+student.getTotalMarks());
	
	}
}
