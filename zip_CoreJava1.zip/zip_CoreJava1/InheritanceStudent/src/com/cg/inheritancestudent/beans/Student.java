package com.cg.inheritancestudent.beans;
public abstract class Student {
	private int rollNumber,totalMarks, marks;
	private String firstName,lastName;
	
	public Student() {
		super();
	}

	public Student(int rollNumber, int marks, String firstName, String lastName) {
		super();
		this.rollNumber = rollNumber;
		this.marks = marks;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public int getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public int getTotalMarks() {
		return totalMarks;
	}

	public void setTotalMarks(int totalMarks) {
		this.totalMarks = totalMarks;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}
	
	public void calculateMarks() {
		totalMarks = marks;
	}
}
