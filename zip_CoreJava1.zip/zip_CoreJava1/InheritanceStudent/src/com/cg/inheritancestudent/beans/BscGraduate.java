package com.cg.inheritancestudent.beans;
public final class BscGraduate extends Student {
	private int  subjects,duration,degree,finalmarks;
	
	public BscGraduate() {
		super();
	}

	public BscGraduate(int rollNumber, int marks, String firstName, String lastName, int subjects) {
		super(rollNumber, marks, firstName, lastName);
		this.subjects = subjects;
	}

	public BscGraduate(int subjects, int duration, int degree, int finalmarks) {
		super();
		this.subjects = subjects;
		this.duration = duration;
		this.degree = degree;
		this.finalmarks = finalmarks;
	}
	
	public int getSubject() {
		return subjects;
	}

	public void setSubject(int subjects) {
		this.subjects = subjects;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public int getDegree() {
		return degree;
	}

	public void setDegree(int degree) {
		this.degree = degree;
	}

	public int getSubjects() {
		return subjects;
	}

	public void setSubjects(int subjects) {
		this.subjects = subjects;
	}

	public int getFinalmarks() {
		return finalmarks;
	}

	public void setFinalmarks(int finalmarks) {
		this.finalmarks = finalmarks;
	}

	@Override
	public void calculateMarks() {
		super.calculateMarks();
		this.finalmarks = this.getMarks()*this.getSubjects();
		this.setTotalMarks(getFinalmarks()+getMarks());
	}
	
	

}
