package com.cg.inheritancestudent.beans;
public final class BeGraduate extends Student{
	private int subjects,duration,finalmarks;
	private String degree;
	
	public BeGraduate() {
		super();
	}

	public BeGraduate(int rollNumber, int marks, String firstName, String lastName, int subjects) {
		super(rollNumber, marks, firstName, lastName);
		this.subjects = subjects;
	}

	public BeGraduate(int subject, int duration,String degree) {
		super();
		this.subjects = subjects;
		this.duration = duration;
		this.degree = degree;
	}

	public int getSubjects() {
		return subjects;
	}

	public void setSubjects(int subjects) {
		this.subjects = subjects;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getDegree() {
		return degree;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}
	
	public int getFinalmarks() {
		return finalmarks;
	}

	public void setFinalmarks(int finalmarks) {
		this.finalmarks = finalmarks;
	}
	public void degree() {
		System.out.println("BE Student");
	}

	@Override
	public void calculateMarks() {
	super.calculateMarks();
	this.finalmarks = this.getMarks()*this.getSubjects();
	this.setTotalMarks(getFinalmarks()+getMarks());
	}

	/*public void calculateMarks() {
		this.finalMarks = this.getMarks()*this.getSubjects();
	*/
	
	
	}

