package com.cg.payroll.test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.payroll.associatedao.AssociateDAO;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServiesImpl;
public class PayrollServicesTestEasyMock {
		private static PayrollServices payrollServices;
		private static AssociateDAO mockAssociateDao;
		
		/*
@BeforeClass
		public static void setUpTestEnv() {
			mockAssociateDao = EasyMock.mock(AssociateDAO.class);
			payrollServices = new PayrollServiesImpl(mockAssociateDao);
		}
		
@Before
		public void setUpTestMockData() {
			Associate associate1 = new Associate(101, 15, "Sheetal", "Chotaliya", "department", "Analyst", "ABC345", "sheetal@gmail.com", new Salary(9000, 160, 120), new BankDetails(12345, "ICICI", "ICICI890"));
			Associate associate2 = new Associate(102, 10, "Priyanka", "Patil", "ab department", "Trainee", "IJGFA689", "priyanka@gmail.com", new Salary(12000, 57, 89), new BankDetails(7489323, "ICICI", "ICICI6373"));
			Associate associate3 = new Associate(103,17, "Anamika", "Bhadouriya", "xyz", "SR", "UHGYT89", "anamika@gmail.com", new Salary(10000, 170, 569), new BankDetails(576894, "HDFC", "HDFC758"));
		
			ArrayList<Associate> associateList = new ArrayList<>();
			associateList.add(associate1);
			associateList.add(associate2);
			
			EasyMock.expect(mockAssociateDao.save(associate3)).andReturn(associate3);
			
			EasyMock.expect(mockAssociateDao.findOne(101)).andReturn(associate1);
			EasyMock.expect(mockAssociateDao.findOne(102)).andReturn(associate2);
			EasyMock.expect(mockAssociateDao.findOne(1234)).andReturn(null);
			EasyMock.expect(mockAssociateDao.findAll()).andReturn(associateList);
			EasyMock.expect(mockAssociateDao.save(associate3)).andReturn(associate3);
			EasyMock.replay(mockAssociateDao);
		}
		
@Test(expected = AssociateDetailsNotFoundException.class)
	public void testGetAssociateDataForInvalidAssociateId() throws AssociateDetailsNotFoundException {
		payrollServices.getAssociateDetails(1234);
		EasyMock.verify(mockAssociateDao.findOne(1234));
	}
	
@Test
		public void testGetAssociateDataForValidAssociateId() throws AssociateDetailsNotFoundException{
		Associate expectedAssociate = new Associate(101, 15, "Sheetal","Chotaliya", "department", "Analyst", "ABC345", "sheetal@gmail.com" , new Salary(9000, 160, 120), new BankDetails(12345, "ICICI", "ICICI890"));
		Associate actualAssociate = payrollServices.getAssociateDetails(101);
	
		//EasyMock.verify(mockAssociateDao.findOne(101));
		assertEquals(expectedAssociate,actualAssociate);
	}
	
@After
	public void tearDownTestData() {
	EasyMock.resetToDefault(mockAssociateDao);
}
	
@AfterClass
	public static void tearDownTestEnv() {
		payrollServices = null;
		mockAssociateDao = null;
	}
	*/
}
		

