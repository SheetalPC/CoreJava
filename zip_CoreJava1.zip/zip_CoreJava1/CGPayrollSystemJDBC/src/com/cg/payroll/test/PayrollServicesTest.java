package com.cg.payroll.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServiesImpl;
public class PayrollServicesTest {
		static PayrollServices payrollServices;

		/*@BeforeClass
		public static void setUpTestEnv() {
			payrollServices = new PayrollServiesImpl();
		}
		@Before
		public void setUpTestData() {
		Associate associate1 = new Associate(101, 15, "Sheetal", "Chotaliya", "department", "Analyst", "ABC345", "sheetal@gmail.com", new Salary(9000, 160, 120), new BankDetails(12345, "ICICI", "ICICI890"));
		Associate associate2 = new Associate(102, 16, "Priyanka", "Patil", "abc", "Sr.", "THUI76", "priyanka@gmail.com", new Salary(6000, 12,0, 0, 0, 0, 12, 67, 0, 0, 0), new BankDetails(67543, "ICICI", "ICICI789"));
		
		PayrollUtil.associates.put(associate1.getAssociateID(), associate1);
		PayrollUtil.associates.put(associate2.getAssociateID(), associate2);
		PayrollUtil.ASSOCIATE_ID_COUNTER =103;
		}
		@Test
		public void testAcceptAssociateDetailsForValidData() {
			int expectedAssociateId =103;
			int actualAssociateId = payrollServices.acceptAssociateDetails("Sukanya", "Pimparkar", "sukku@gmail.com", "EFG","Trainee Engineer", "HUI975", 89, 8000, 140, 190, 78654, "HDFC", "HDFC6789");
			Assert.assertEquals(expectedAssociateId,actualAssociateId);
		}
		
		@Test(expected = AssociateDetailsNotFoundException.class)
		public void testGetAssociateDataForInvalisAssociateId() throws AssociateDetailsNotFoundException {
			payrollServices.getAssociateDetails(12212);
		}
		
		@Test
		public void testGetAssociateDataForValidAssociateId() throws AssociateDetailsNotFoundException{
			Associate expectedAssociate = new Associate(102, 16, "Priyanka", "Patil", "abc", "Sr", "THUI76", "priyanka@gmail.com",new Salary(6000, 12,0, 0, 0, 0, 12, 67, 0, 0, 0), new BankDetails(67543, "ICICI", "ICICI789"));
				Associate actualAssociate = payrollServices.getAssociateDetails(102);
				Assert.assertEquals(expectedAssociate, actualAssociate);
		}
		
		@After
		public void tearDownTestData() {
			PayrollUtil.ASSOCIATE_ID_COUNTER = 100;
			PayrollUtil.associates.clear();
		}
		
		@AfterClass
		public static void tearDownTestEnv() {
			payrollServices = null;
		}*/
	}

