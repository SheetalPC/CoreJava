package com.cg.payroll.associatedao;

import java.util.List;

import com.cg.payroll.beans.Associate;

public class AssociateDAOImpl implements AssociateDAO{

	@Override
	public Associate save(Associate associate) {
		return null;
	}

	@Override
	public boolean update(Associate associate) {
		return false;
	}

	@Override
	public Associate findOne(int associateId) {
		return null;
	}

	@Override
	public List<Associate> findAll() {
		return null;
	}
	
}
