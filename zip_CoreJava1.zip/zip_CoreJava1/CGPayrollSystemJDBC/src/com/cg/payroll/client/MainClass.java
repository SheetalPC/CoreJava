package com.cg.payroll.client;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServiesImpl;
import com.cg.payroll.util.DBUtil;
import oracle.jdbc.driver.DBConversion;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;
import com.cg.payroll.ObjectSerialization;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
public class MainClass {
	public static void main(String[] args) {
		}
}			

