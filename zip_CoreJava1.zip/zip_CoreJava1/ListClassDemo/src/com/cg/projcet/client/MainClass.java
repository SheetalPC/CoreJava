package com.cg.projcet.client;
import java.util.ArrayList;
import java.util.stream.Stream;
import com.cg.projcet.beans.Associate;
public class MainClass {
    public static void main(String[] args) {
        ArrayList<Associate> associates= new ArrayList<>();
        //insertion
        associates.add(new Associate(111, 5000, "Sheetal", "Chotaliya"));
        associates.add(new Associate(112, 10000, "Anamika ", "Bhadouriya"));
        associates.add(new Associate(113, 7000, "Sukanya", "Pimparkar"));
        associates.add(new Associate(114, 8000, "Priyanka", "Patil"));
        Stream<Associate> stream1=associates.stream();
        Stream<Associate> stream2=stream1.distinct();
        Stream<Associate> stream3=stream2.filter((associate)->associate.getFirstName().startsWith("S"));
        System.out.println(stream3.count());
        // stream3.forEach(associate->System.out.println(associate));


        associates.stream()
        .distinct()
        .filter(associate->associate.getFirstName().startsWith("S"))
        .forEach((associate) ->System.out.println(associate));



    }
}
