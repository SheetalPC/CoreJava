package com.cg.project.collectiondemo;
import java.util.ArrayList;
import java.util.Collections;
import com.cg.projcet.beans.Associate;

public class ListClassesDemo{
	public static void arrayListClassDemo() {
	ArrayList<Associate> associates = new ArrayList<>();
	
	//insert
	associates.add(new Associate(111, 1500, "Sheetal", "Chotaliya"));
	associates.add(new Associate(113, 1700, "Anamika", "Bhadouriya"));
	associates.add(new Associate(112, 1800, "Sukanya", "Pimparkar"));
	associates.add(new Associate(114, 1200, "Priyanka", "Patil"));
	
	//search
	Associate associateToBeSearch = new Associate(112, 1800, "Sukanya", "Pimparkar");
	int idx = associates.indexOf(associateToBeSearch);
	System.out.println(idx);
	
	//remove
	System.out.println(associates.remove(associateToBeSearch));
	
	//sort
	Collections.sort(associates);
	Collections.sort(associates, new AssociateComparator());
	
	//iteration
	
	for(Associate associate : associates)
		System.out.println(associate);
}
	}
