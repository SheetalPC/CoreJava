package com.cg.objectclassmethoddemo.client;

import com.cg.objectclassmethoddemo.beans.Address;
import com.cg.objectclassmethoddemo.beans.Associate;

public class MainClass {
public static void main(String[] args) {
	Associate associate1 = new Associate(111, 10000, 200000, "Sheetal", "Chotaliya", new Address(411052,"Pune", "Maharashtra"));
		Associate associate2 = new Associate(111, 10000, 200000, "Sheetal", "Chotaliya", new Address(411052,"Pune", "Maharashtra"));
		
		if(associate1 == associate2)
			System.out.println("Data is same..");
		else
			System.out.println("Data is not same..");
		
		if(associate1.equals(associate2))
			System.out.println("Same Data");
		else
			System.out.println("Not Same Data");
	}

}
