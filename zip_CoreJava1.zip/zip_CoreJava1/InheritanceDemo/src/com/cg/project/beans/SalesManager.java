package com.cg.project.beans;
public final class SalesManager extends PEmployee{
	private int salesAmount,commission;
	
	public SalesManager() {
		super();
	}
	
	public SalesManager(int employeeId, int basicSalary, String firstName, String lastName,int salesAmount) {
		super(employeeId, basicSalary, firstName, lastName);
		this.salesAmount = salesAmount;	
	}
	public int getSalesAmount() {
		return salesAmount;
	}

	public void setSalesAmount(int salesAmount) {
		this.salesAmount = salesAmount;
	}

	public int getCommission() {
		return commission;
	}

	public void setCommission(int commission) {
		this.commission = commission;
	}
	
	public void SalesManagerProject() {
		System.out.println("Sales has Done");
	}

	@Override
	public final void calculateSalary() {
		super.calculateSalary();
		this.setTotalSalary(getTotalSalary()+commission);
	}

}
