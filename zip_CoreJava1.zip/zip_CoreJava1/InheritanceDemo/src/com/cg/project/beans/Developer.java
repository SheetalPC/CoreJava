package com.cg.project.beans;
public final class Developer extends PEmployee{
	private int noOfProjectDone,incentive;
	public Developer(){
		super();
	}
	public Developer(int employeeId, int basicSalary, String firstName, String lastName,int noOfProjectDone) {
		super(employeeId, basicSalary, firstName, lastName);
		this.noOfProjectDone = noOfProjectDone;
	}
	public int getNoOfProjectDone() {
		return noOfProjectDone;
	}
	public void setNoOfProjectDone(int noOfProjectDone) {
		this.noOfProjectDone = noOfProjectDone;
	}
	public int getIncentive() {
		return incentive;
	}
	public void setIncentive(int incentive) {
		this.incentive = incentive;
	}

	public void developerProject() {
		System.out.println("Project has completed");
	}
	@Override
	public final void calculateSalary() {
				super.calculateSalary();
				this.setTotalSalary(getTotalSalary()+incentive);
	}
	
	
	

	
}
