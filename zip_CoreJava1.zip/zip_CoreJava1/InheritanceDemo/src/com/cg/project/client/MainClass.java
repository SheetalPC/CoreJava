package com.cg.project.client;
import com.cg.project.beans.Employee;
import com.cg.project.beans.PEmployee;
import com.cg.project.beans.SalesManager;
import com.cg.project.beans.CEmployee;
import com.cg.project.beans.Developer;

public abstract class MainClass {

	public static void main(String[] args) {
		
		/*Employee emp = new Employee(111,12000,"Sheetal","Chotaliya");
		emp.calculateSalary();
		System.out.println(emp.getEmployeeId()+ " " +emp.getTotalSalary()+" "+emp.getFirstName()+ " " +emp.getLastName());
		
		PEmployee pemp = new PEmployee(112, 50000, "Anamika", "Bhadouriya");
		pemp.calculateSalary();
		System.out.println(pemp.getEmployeeId()+" "+pemp.getFirstName()+" "+pemp.getLastName()+" "+pemp.getTotalSalary());
		
		CEmployee cemp = new CEmployee(113,"Shiiv","Shri",400);
		cemp.signContract();
		cemp.calculateSalary();
		System.out.println(cemp.getEmployeeId()+" "+cemp.getFirstName()+" "+cemp.getLastName()+" "+cemp.getTotalSalary());
	
		Developer devEmp = new Developer(114, 30000, "Priyanka", "Patil", 2);
		devEmp.developerProject();
		devEmp.calculateSalary();
		System.out.println(devEmp.getEmployeeId()+" "+devEmp.getFirstName()+" "+devEmp.getLastName()+" "+devEmp.getTotalSalary());
	
		SalesManager salesmanager = new SalesManager(115,4000, "Sukanya", "Pimparkar", 1000);
		salesmanager.SalesManagerProject();
		salesmanager.calculateSalary();
		System.out.println(salesmanager.getEmployeeId()+" "+salesmanager.getFirstName()+" "+salesmanager.getLastName()+" "+salesmanager.getTotalSalary());
	*/
		
		Employee emp ;
		
		
		emp = new PEmployee(112, 50000, "Priyanka", "Patil");
		emp.calculateSalary();
		System.out.println(emp.toString());
		
		emp = new CEmployee(113, "Sukanya", "Pimparkar", 2);
		CEmployee cemp = (CEmployee) emp;
		cemp.signContract();
		emp.calculateSalary();
		System.out.println(cemp.getEmployeeId()+" "+cemp.getFirstName()+" "+cemp.getLastName()+" "+cemp.getTotalSalary());
		System.out.println(emp.toString());
		
		emp = new Developer(114, 3000, "Renuka", "Deshmukh", 2);
		Developer dev = (Developer) emp;
		dev.developerProject();
		emp.calculateSalary();
		System.out.println(emp.getEmployeeId()+" "+emp.getFirstName()+" "+emp.getLastName()+" "+emp.getTotalSalary());
		System.out.println(emp.toString());
		
		emp = new SalesManager(115, 20000, "Anamika", "Bhadouriya", 8);
		SalesManager sales = (SalesManager) emp;
		sales.SalesManagerProject();
		emp.calculateSalary();
		System.out.println(emp.getEmployeeId()+" "+emp.getFirstName()+" "+emp.getLastName()+" "+emp.getTotalSalary());
		System.out.println(emp.toString());
		
		}
}
