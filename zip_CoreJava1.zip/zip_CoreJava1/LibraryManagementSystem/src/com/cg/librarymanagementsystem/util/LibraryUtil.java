package com.cg.librarymanagementsystem.util;

import com.cg.librarymanagementsystem.beans.Member;

public class LibraryUtil {
	private static int MEMBER_ID_COUNTER = 100;
	private static int MEMBER_IDX = 0;
	public static Member[] member;
	
	public static int getMEMBER_ID_COUNTER() {
		return ++MEMBER_ID_COUNTER;
	}
	public static int getMEMBER_IDX() {
		MEMBER_ID_COUNTER++;
		return MEMBER_IDX;
	}
}
