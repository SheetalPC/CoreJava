package com.cg.librarymanagementsystem.beans;
public class Book {
	private int bookId,price;
	private String title,publication;
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getPublication() {
		return publication;
	}
	public void setPublication(String publication) {
		this.publication = publication;
	}
	public Book(int bookId, int price, String title, String publication) {
		super();
		this.bookId = bookId;
		this.price = price;
		this.title = title;
		this.publication = publication;
	}
}
