package com.cg.librarymanagementsystem.beans;
public class Member {
	private int memberId,phoneNumber;
	private String firstName,lastName,emailId;
	private int dateOfIssue,dateOfReturn;
	
	public Member(int memberId, int phoneNumber, String firstName, String lastName, String emailId, int dateOfIssue,
			int dateOfReturn, Address address) {
		super();
		this.memberId = memberId;
		this.phoneNumber = phoneNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.dateOfIssue = dateOfIssue;
		this.dateOfReturn = dateOfReturn;
		this.address = address;
	}
	public Member() {}

	private Address address;	//has-a relationship(class has reference of another class as a attribute/reference)
	
	public int getMemberId() {
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public int getDateOfIssue() {
		return dateOfIssue;
	}
	public void setDateOfIssue(int dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}
	public int getDateOfReturn() {
		return dateOfReturn;
	}
	public void setDateOfReturn(int dateOfReturn) {
		this.dateOfReturn = dateOfReturn;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
}
