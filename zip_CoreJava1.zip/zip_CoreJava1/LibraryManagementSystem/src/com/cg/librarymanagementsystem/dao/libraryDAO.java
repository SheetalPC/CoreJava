package com.cg.librarymanagementsystem.dao;

import com.cg.librarymanagementsystem.beans.Book;
import com.cg.librarymanagementsystem.beans.Member;

public interface libraryDAO {
	
	Member save(int memberId);
	boolean update(Member member);
	static Member findOne(int memberId) {
		// TODO Auto-generated method stub
		return null;
	}
	Member[] findAll();
	Book save1(Book book);
}
