package com.cg.librarymanagementsystem.dao;
import com.cg.librarymanagementsystem.beans.Book;
import com.cg.librarymanagementsystem.beans.Member;
import com.cg.librarymanagementsystem.util.LibraryUtil;
public class libraryDaoImpl implements libraryDAO{
	@Override
	public Book save1(Book book) {
		return null;
	}

	@Override
	public boolean update(Member member) {
		return false;
	}

/*	@Override
	public Member findOne(int memberId) {
		for (Member member : LibraryUtil.member)
			if(member != null && member.getMemberId() == memberId)
				return member;
		return null;
	}
	*/
	@Override
	public Member[] findAll() {
		return null;
	}

	@Override
	public Member save(int memberId) {
		// TODO Auto-generated method stub
		return null;
	}
}
