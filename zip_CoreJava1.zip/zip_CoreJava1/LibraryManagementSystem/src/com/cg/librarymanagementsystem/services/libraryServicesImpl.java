package com.cg.librarymanagementsystem.services;
import com.cg.librarymanagementsystem.beans.Address;
import com.cg.librarymanagementsystem.beans.Book;
import com.cg.librarymanagementsystem.beans.Member;
import com.cg.librarymanagementsystem.dao.libraryDAO;
import com.cg.librarymanagementsystem.dao.libraryDaoImpl;
import com.cg.librarymanagementsystem.exception.BookDetailsNotFound;
import com.cg.librarymanagementsystem.exception.MemberDetailsNotFoundException;
public class libraryServicesImpl implements libraryServices{
	private libraryDAO librarydao = new libraryDaoImpl();

	@Override
	public int acceptMemberDetails(int memberId, int phoneNumber, String firstName, String lastName, String emailId,
			int pinCode, String city, String state, String country) {
		Member member = new Member(memberId, phoneNumber, firstName, lastName, emailId, date OfIssue, dateOfReturn), new Address(pinCode, city, state, country));
		member = librarydao.save(memberId);
		return member.getMemberId();
	}

	@Override
	public int acceptBookDetails(int bookId, int price, String title, String publication) {
		return 0;
	}

	@Override
	public Member getMemberDetails(int memberId) throws MemberDetailsNotFoundException {
		Member member = libraryDAO.findOne(memberId);
		if(member == null) throw new MemberDetailsNotFoundException("Member details not found for memberId" );
return member;
	}

	@Override
	public Book getBookDetails(int bookId) throws BookDetailsNotFound {
		return null;
	}

	@Override
	public int calculateDue(int memberId) throws MemberDetailsNotFoundException {
	int difference = dateOfIssue - dateOfReturn;
	
		return 0;
	}
}

	