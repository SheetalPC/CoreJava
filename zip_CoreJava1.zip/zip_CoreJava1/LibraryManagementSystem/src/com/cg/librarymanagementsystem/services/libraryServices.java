package com.cg.librarymanagementsystem.services;
import com.cg.librarymanagementsystem.beans.Book;
import com.cg.librarymanagementsystem.beans.Member;
import com.cg.librarymanagementsystem.exception.BookDetailsNotFound;
import com.cg.librarymanagementsystem.exception.MemberDetailsNotFoundException;

public interface libraryServices {
	public int acceptMemberDetails(int memberId, int phoneNumber, String firstName, String lastName, String emailId,int pinCode, String city, String state, String country);
	public int acceptBookDetails(int bookId, int price, String title, String publication);
	
	 Member getMemberDetails(int memberId) throws MemberDetailsNotFoundException;
	 Book getBookDetails(int bookId) throws BookDetailsNotFound;
	 int calculateDue(int memberId) throws MemberDetailsNotFoundException;
}
