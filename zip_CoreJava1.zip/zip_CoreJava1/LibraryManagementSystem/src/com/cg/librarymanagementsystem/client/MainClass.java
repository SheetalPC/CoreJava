package com.cg.librarymanagementsystem.client;

import com.cg.librarymanagementsystem.services.libraryServices;
import com.cg.librarymanagementsystem.services.libraryServicesImpl;

public class MainClass {
public static void main(String[] args) {

	libraryServices libraryservice = new libraryServicesImpl();
	
	int memberId = libraryservice.acceptMemberDetails(111, 83789, "Sheetal", "Chotaliya", "sheetal@gmail.com",411052 , "Pune", "Maharashtra", "India");
	System.out.println("MemberId : " +memberId);
}
}
