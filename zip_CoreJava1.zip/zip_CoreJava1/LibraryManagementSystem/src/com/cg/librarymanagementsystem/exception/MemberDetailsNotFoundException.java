package com.cg.librarymanagementsystem.exception;

public class MemberDetailsNotFoundException extends Exception {

	public MemberDetailsNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MemberDetailsNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public MemberDetailsNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MemberDetailsNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MemberDetailsNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
