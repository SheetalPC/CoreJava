package com.cg.bank.services;
import com.cg.bank.customer.Customer;
import com.cg.bank.customernotfoundexception.CustomerNotFoundException;

public interface BankService {
	int acceptCustomerDetails(int customerID, int mobileNo, int aadharNo, int dofBirth, String firstName, String lastName,
			String emailID, String panID, String city,String state,String country,int accountNo,int accountBalance,String accountType);
	int deposit(int amount,int customerID)throws CustomerNotFoundException;
	Customer getCustomerDetails(int customerID)throws CustomerNotFoundException;
	int withDraw(int amount,int customerID )throws CustomerNotFoundException;

}
