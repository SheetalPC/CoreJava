package com.cg.payroll.controllers;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServiesImpl;

@WebServlet("/CalculateSalaryServlets")
public class CalculateSalaryServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PayrollServices payrollServices= new PayrollServiesImpl();
    Salary salary;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		int associateID = Integer.parseInt(request.getParameter("associateID"));
        try {
            payrollServices.calculateNetSalary(associateID);
            salary= payrollServices.getAssociateDetails(associateID).getSalary();
        } catch (AssociateDetailsNotFoundException e) {
            e.printStackTrace();
        }       
        request.setAttribute("salary", salary);
        request.getRequestDispatcher("SalaryCalculated.jsp").forward(request, response);
	
	}
}
