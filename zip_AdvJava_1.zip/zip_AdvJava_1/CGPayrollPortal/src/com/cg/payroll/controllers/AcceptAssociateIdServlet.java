package com.cg.payroll.controllers;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServiesImpl;

@WebServlet("/AcceptAssociateIdServlet")
public class AcceptAssociateIdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PayrollServices payrollServices = new PayrollServiesImpl();
	Associate associate;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int associateId = Integer.parseInt(request.getParameter("associateId"));
		try {
			associate = payrollServices.getAssociateDetails(associateId);
		} catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}
		RequestDispatcher dispatcher = null;
		 dispatcher = request.getRequestDispatcher("successPage.jsp");
			request.setAttribute("associate", associate);
			dispatcher.forward(request, response);
		
	}
}
