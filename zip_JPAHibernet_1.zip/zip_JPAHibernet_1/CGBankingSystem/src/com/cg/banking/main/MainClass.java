package com.cg.banking.main;

import java.util.Scanner;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA-PU");
	
	BankingServices bankingServices = new BankingServicesImpl();
    Scanner scanner = new Scanner(System.in);
    int i = 0,choice,pinNumber;
    float amount;
    long accountNo,toAccountNo,fromAccountNo;
    Account account;
    String accountType;
    try {
    do { 
            System.out.println("\n\n1. Open Account");
            System.out.println("2. Deposit Amount");
            System.out.println("3. Withdraw Amount");
            System.out.println("4. Fund Transfer ");
            System.out.println("5. Get Account Details");
            System.out.println("6. Get All Accounts Detail");
            System.out.println("7. Get Account All transactions Details");
            System.out.println("8. Get Account Status");
            System.out.println("9. Exit");
            choice = scanner.nextInt();
            scanner.nextLine();
            switch(choice) {
            case 1:
                System.out.print("Enter account Type : ");
                accountType = scanner.nextLine();
                System.out.print("Enter Initial balance : ");
                amount = scanner.nextInt();
                account = bankingServices.openAccount(accountType, amount);
                System.out.println("your account open successfully and following are the details :- \nAccount Number : "+account.getAccountNo()+"\nPin number : "+account.getPinNumber()+"\nAvailable balance : "+account.getAccountBalance());
                break;
            case 2:
                System.out.print("Enter account number : ");
                accountNo = scanner.nextLong();
                System.out.println("Enter amount to deposit : ");
                amount = scanner.nextFloat();
                System.out.println(bankingServices.depositAmount(accountNo, amount));
                break;
            case 3:
                System.out.print("Enter account number : ");
                accountNo = scanner.nextLong();
                System.out.println("Enter amount to withdraw : ");
                amount = scanner.nextFloat();
                System.out.println("Enter amount to pinNumber : ");
                pinNumber = scanner.nextInt();
                System.out.println(bankingServices.withdrawAmount(accountNo, amount, pinNumber));
                break;
            case 4://FUND TRANSFER
                System.out.print("Enter your account number : ");
                toAccountNo = scanner.nextLong();
                System.out.print("Enter receiver account number : ");
                fromAccountNo = scanner.nextLong();
                System.out.print("Enter your transfer amount : ");
                amount = scanner.nextFloat();
                System.out.println("Enter your pinNumber : ");
                pinNumber = scanner.nextInt();
                if(bankingServices.fundTransfer(toAccountNo, fromAccountNo, amount, pinNumber))
                    System.out.println("Funds transferred successfully.");
                break;
            case 5://GET ACCOUNT DETAILS
                System.out.print("Enter account number : ");
                accountNo = scanner.nextLong();
                System.out.println(bankingServices.getAccountDetails(accountNo).toString());
                break;
            case 6://GET ALL ACCOUNTS DETAIL
                System.out.println("All Accounts Details");
                System.out.println(bankingServices.getAllAccountDetails());
                break;
            case 7://GET ACCOUNT TRANSACTIONS DETAIL
                System.out.print("Enter account number : ");
                accountNo = scanner.nextLong();
                System.out.println(bankingServices.getAccountAllTransaction(accountNo));
                break;
            case 8://get account status
                System.out.println("Enter your account Number : ");
                accountNo = scanner.nextLong();
                System.out.println("Your status is : "+bankingServices.accountStatus(accountNo));
                break;
            case 9:
                System.out.println("thank you.");
                System.exit(0);
                
        }
    }while(i!=9);
    } catch (InvalidAmountException e) {
        e.printStackTrace();
    } catch (InvalidAccountTypeException e) {
        e.printStackTrace();
    } catch (BankingServicesDownException e) {
        e.printStackTrace();
    } catch (AccountNotFoundException e) {
        e.printStackTrace();
    } catch (AccountBlockedException e) {
        e.printStackTrace();
    } catch (InsufficientAmountException e) {
        e.printStackTrace();
    } catch (InvalidPinNumberException e) {
        e.printStackTrace();
    }
}
}
