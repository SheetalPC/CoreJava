package com.cg.payroll.client;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServiesImpl;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import com.cg.payroll.ObjectSerialization;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
public class MainClass {
	public static void main(String[] args) throws AssociateDetailsNotFoundException {
		PayrollServices payrollService = new PayrollServiesImpl();
		int associateId = payrollService.acceptAssociateDetails("Sheetal", "Chotaliya", "sheetal@gmail.com", "IT", "Analyst", "BCK987", 7000, 21000, 4000, 5000, 567232, "ICICI", "ICICI678");
		System.out.println(associateId);
		
		Associate associate = payrollService.getAssociateDetails(associateId);
		System.out.println(associate.toString());
		System.out.println(payrollService.getAllAssociateDetails());
	}
}
