package com.cg.payroll;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class ReadWrite {
	public static void characterReadWrite(File fromFile, File toFile) throws FileNotFoundException,IOException{
		try(BufferedReader srcReader = new BufferedReader(new FileReader(fromFile))){
			try(BufferedWriter destWriter = new BufferedWriter(new FileWriter(toFile))){
				String data = " " ;
				while(((data = srcReader.readLine())!= null))
					destWriter.write(data);
				System.out.println("File written on " +toFile.getAbsolutePath());
			}
		}
	}
}
