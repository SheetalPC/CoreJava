package com.cg.payroll.services;
import java.util.List;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
public interface PayrollServices {
	public  int acceptAssociateDetails(String firstName, String lastName, String emailID, String department, String designation,
			String panCard, int yearlyInvestmentUnder80C, int BasicSalary, int epf, int companypf, int accountNumber,
				String bankName, String ifscCode);
	
	 int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException;
	 Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException;
	 List<Associate> getAllAssociateDetails();
}
