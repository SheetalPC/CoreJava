package com.cg.payroll.services;
import java.io.Serializable;
import java.util.List;
import com.cg.payroll.associatedao.AssociateDAO;
import com.cg.payroll.associatedao.AssociateDAOImpl;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public class PayrollServiesImpl implements PayrollServices,Serializable{
	//private AssociateDAO associateDAO = new AssociateDAOImpl();	//associateDAO is reference of interface AssociateDAO
	
	//for easymock (14-23)
	private AssociateDAO associateDAO;

	
	public PayrollServiesImpl() {
		associateDAO = new AssociateDAOImpl();
	}
	
	public PayrollServiesImpl(AssociateDAO associateDAO) {
		super();
		this.associateDAO = associateDAO;
	}
	
	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailID, String department,
			String designation, String panCard, int yearlyInvestmentUnder80C, int BasicSalary, int epf, int companypf,
			int accountNumber, String bankName, String ifscCode) {
		
		Associate associate = new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, panCard, emailID, new Salary(BasicSalary, epf, companypf), new BankDetails(accountNumber, bankName, ifscCode));
		associate = associateDAO.save(associate);
		return associate.getAssociateID();
	}

	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate = this.getAssociateDetails(associateId);
		int hra = associate.getSalary().getBasicSalary()*40/100;
		int conveyanceAllowance = associate.getSalary().getConveyanceAllowance()*30/100;
		int personalAllowance = associate.getSalary().getPersonalAllowance()*20/100;
		int otherAllowance = associate.getSalary().getOtherAllowance()*20/100;
		int grossSalary =associate.getSalary().getBasicSalary() + hra + conveyanceAllowance + personalAllowance + otherAllowance + associate.getSalary().getEpf() + associate.getSalary().getCompanyPf() ; 
		int annualSalary = grossSalary*12;
		int taxableAmount = annualSalary - associate.getYearlyInvestmentUnder80C() - associate.getSalary().getEpf();
		System.out.println("Taxable Amount is: " +taxableAmount);
		if(annualSalary <= 250000)
			return grossSalary - associate.getSalary().getEpf() - associate.getSalary().getCompanyPf();
		else if(annualSalary > 250000 && taxableAmount <= 500000) {
			taxableAmount = 2500000;
			int monthlyTax = (taxableAmount/10)/12;
			return grossSalary - monthlyTax - associate.getSalary().getEpf() - associate.getSalary().getCompanyPf();
		}
		else if(annualSalary > 500000 && taxableAmount <= 1000000) {
			taxableAmount = 500000;
			int monthlyTax = (taxableAmount/5)/12 + 25000;
			return grossSalary - monthlyTax - associate.getSalary().getEpf() - associate.getSalary().getCompanyPf();
		}
		else if(annualSalary > 1000000) {
			taxableAmount = 1000000;
			int monthlyTax = ((taxableAmount*30)/100 + 125000)/12;
			return grossSalary - monthlyTax - associate.getSalary().getEpf() - associate.getSalary().getCompanyPf();
		}
		return 0;
	}
	
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate = associateDAO.findOne(associateId);
				if(associate == null) throw new AssociateDetailsNotFoundException("Associate details not found for associateId" );
		return associate;
	}

	/*@Override
	public Associate[] getAllAssociateDetails() {
		return associateDAO.findAll();
	}
	*/
	
	@Override
	public List<Associate> getAllAssociateDetails() {
		return associateDAO.findAll();
	}

	/*@Override
	public int acceptAssociateDetails() {
		return 0;
		
	}
*/
}
