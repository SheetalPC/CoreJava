package com.cg.session.controllers;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.session.beans.UserBean;

@WebServlet("/SocialInfoServlet")
public class SocialInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String fruitName = request.getParameter("fruitName");
		String movieName = request.getParameter("movieName");
		String bookName = request.getParameter("bookName");
		UserBean userBean = new UserBean(fruitName, movieName, bookName);
		
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		out.println("<div align = 'center'>");
		out.println("firstName: " + firstName + "<br>");
		out.println("lastName: " + lastName + "<br>");
		out.println("fruitName: " + fruitName + "<br>");
		out.println("movieName: " + movieName + "<br>");
		out.println("bookName: " + bookName + "<br>");
		out.println("</div>");
		out.println("</body></html>");
	
	}
}
