package com.cg.project.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;


@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;          
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int associateId = Integer.parseInt(request.getParameter("associateId"));
		String password = request.getParameter("password");
		
		UserBean bean = new UserBean(associateId,password);
		RequestDispatcher dispatcher = null;
		if(bean.getAssociateId()==111&&bean.getPassword().equals("sasa")) {
			dispatcher = request.getRequestDispatcher("loginSuccessPage.jsp");
			request.setAttribute("bean", bean);
			dispatcher.forward(request, response);
		}
		else {
			dispatcher = request.getRequestDispatcher("loginPage.jsp");
			request.setAttribute("error", "AssociateId or Password is Incorrect");
			dispatcher.forward(request, response);
		}
		}
	}


