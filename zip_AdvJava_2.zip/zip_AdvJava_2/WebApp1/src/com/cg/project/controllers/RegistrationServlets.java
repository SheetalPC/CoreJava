package com.cg.project.controllers;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.DispatcherType;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.Dispatch;

import com.cg.project.beans.UserBean;

@WebServlet("/registration")
public class RegistrationServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String mobileNo = request.getParameter("mobileNo");
		String emailId = request.getParameter("emailId");
		String graduation = request.getParameter("graduation");
		String gender = request.getParameter("gender");
		String [] communication = request.getParameterValues("communication");
		List<String> communications = Arrays.asList(communication);
		
		UserBean bean = new UserBean(firstName, lastName, mobileNo, emailId, graduation, gender, communications);
		RequestDispatcher dispatcher = null;
		dispatcher = request.getRequestDispatcher("registrationSuccessPage.jsp");
		request.setAttribute("bean", bean);
		dispatcher.forward(request,response);
		
	}

}
