package com.cg.project.beans;
import java.util.List;
public class UserBean {
	private int associateId;
	private String firstName,lastName,mobileNo,emailId,password,graduation,gender;
	private List<String> communications;
	
	public UserBean() {
		super();
	}
	
	public UserBean(int associateId, String password) {
		super();
		this.associateId = associateId;
		this.password = password;
	}

	public UserBean(String firstName, String lastName, String mobileNo, String emailId, String graduation,
			String gender, List<String> communications) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
		this.graduation = graduation;
		this.gender = gender;
		this.communications = communications;
	}

	public UserBean(String firstName, String lastName, String mobileNo, String emailId, String password,
			String graduation, String gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
		this.password = password;
		this.graduation = graduation;
		this.gender = gender;
	}

	public int getAssociateId() {
		return associateId;
	}

	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGraduation() {
		return graduation;
	}

	public void setGraduation(String graduation) {
		this.graduation = graduation;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public List<String> getCommunications() {
		return communications;
	}

	public void setCommunications(List<String> communications) {
		this.communications = communications;
	}
}

