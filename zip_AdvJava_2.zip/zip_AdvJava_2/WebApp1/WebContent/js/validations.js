function validateRegistrationForm(){
	if(registerForm.firstName.value==""){
		alert("Enter first name");
		return false;
	}
	
	else if(registerForm.lastName.value==""){
		alert("Enter last name");
		return false;
	}
	
	else if(registerForm.lastName.value==""){
		alert("Enter last name");
		return false;
	}
	
	else if(registerForm.emailId.value==""){
		alert("Enter email Id");
		return false;
	}
	
	else if(registerForm.department.value==""){
		alert("Enter department");
		return false;
	}
	
	else if(registerForm.designation.value==""){
		alert("Enter designation");
		return false;
	}
	
	else if(registerForm.pancard.value==""){
		alert("Enter pan card number");
		return false;
	}
	
	else if(registerForm.yearlyInvestmentUnder80C.value==""){
		alert("Enter yearly Investment under 80C");
		return false;
	}
	
	else if(registerForm.basicSalary.value==""){
		alert("Enter basic salary");
		return false;
	}
	
	else if(registerForm.bankName.value==""){
		alert("Enter Bank name");
		return false;
	}
	
	else if(registerForm.accountNo.value==""){
		alert("Enter account number");
		return false;
	}
	
	else if(registerForm.ifscCode.value==""){
		alert("Enter ifsc code");
		return false;
	}
}