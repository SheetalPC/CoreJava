function validateRegistrationForm(){
	if(registerForm.associateId.value==""){
		alert("Enter associateId");
		return false;
	}
	
	else if(registerForm.password.value==""){
		alert("Enter password");
		return false;
	}
}