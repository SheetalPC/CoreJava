package com.cg.session.beans;

public class UserBean {
	private String firstName,lastName;
	private String fruitName,movieName,bookName;

	public UserBean(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public UserBean(String fruitName, String movieName, String bookName) {
		super();
		this.fruitName = fruitName;
		this.movieName = movieName;
		this.bookName = bookName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
}
