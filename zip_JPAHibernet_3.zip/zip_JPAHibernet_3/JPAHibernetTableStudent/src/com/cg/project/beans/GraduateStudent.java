package com.cg.project.beans;
import javax.persistence.Entity;

@Entity
public class GraduateStudent extends Student {
private int branch,degree;

public GraduateStudent() {
	super();
}

public GraduateStudent(int branch, int degree) {
	super();
	this.branch = branch;
	this.degree = degree;
}

public int getBranch() {
	return branch;
}

public void setBranch(int branch) {
	this.branch = branch;
}

public int getDegree() {
	return degree;
}

public void setDegree(int degree) {
	this.degree = degree;
}


}
